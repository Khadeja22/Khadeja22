public class OrganizePizza {

  private Pizza[][] pizzaList;

  public OrganizePizza(int rowVals, int colVals) {
    pizzaList = new Pizza[rowVals][colVals];
    for (int i = 0; i < rowVals; i++) {
      for (int j = 0; j < colVals; j++) {
        pizzaList[i][j] = new Pizza();
      }
    }
  }

  public OrganizePizza() {
    this(5, 5);
  }

  public Pizza[][] getPizzas() {
    return pizzaList;
  }

  public Pizza[][] sortRow(int row) {
    int n = pizzaList[row].length;
    for (int i = 0; i < n - 1; i++) {
      int minIndex = i;
      for (int j = i + 1; j < n; j++) {
        if ((pizzaList[row][j].getToppingType()).compareTo(pizzaList[row][minIndex].getToppingType()) < 0) {
          minIndex = j;
        }
      }
      if (minIndex != i) {
        Pizza temp = pizzaList[row][i];
        pizzaList[row][i] = pizzaList[row][minIndex];
        pizzaList[row][minIndex] = temp;
      }
    }
    return pizzaList;
  }

  public Pizza[][] sortCol(int col) {
    for (int i = 0; i < pizzaList.length - 1; i++) {
      int min = i;
      for (int j = i + 1; j < pizzaList.length; j++) {
        if ((pizzaList[j][col].getToppingType()).compareTo(pizzaList[min][col].getToppingType()) < 0) {
          min = j;
        }
      }
      Pizza temp = pizzaList[min][col];
      pizzaList[min][col] = pizzaList[i][col];
      pizzaList[i][col] = temp;
    }
    return pizzaList;

  }

  public Pizza[][] sortRowMajor() {
    for (int i = 0; i < pizzaList.length; i++) {
      this.sortRow(i);
    }
    for (int i = 0; i < pizzaList[0].length; i++) {
      this.sortCol(i);
    }
    return pizzaList;
  }

  public Pizza[][] sortColMajor() {
    this.sortRow(1);
    this.sortCol(0);
    this.sortRow(1);
    return pizzaList;
  }

  public String toString() {
    String prntArray = "";
    for (int i = 0; i < pizzaList.length; i++) {
      for (int j = 0; j < pizzaList[0].length; j++) {
        prntArray = prntArray + pizzaList[i][j].toString() + " ";
      }
      prntArray += "\n";
    }
    return prntArray;
  }

}
