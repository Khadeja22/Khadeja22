import java.util.*;

class Main {
  public static void main(String[] args) {
    // Scanner
    Scanner scan = new Scanner(System.in);
    Scanner newScan = new Scanner(System.in);

    System.out.println("Hello and welcome to Khadeja's Pizzeria!\nYour pizzas: ");

    // Creating three objects

    // Using default constructor
    Pizza p1 = new Pizza();

    // Using parameterized constructor
    Pizza p2 = new Pizza("medium", 8, true, "pepperoni", true, false, 10.00);

    // Using parameterized constructor
    Pizza p3 = new Pizza("large", 12, true, "veggie", true, true, 12.00);

    // To String
    System.out.println(p1 + "\n" + p2 + "\n" + p3);

    // Print number of objects created in the tester program referring to static
    // variable.
    System.out.println(
        "You ordered a total of " + Pizza.getCount() + " pizzas. For all pizzas, you owe us $" + p3.finalCost());

    System.out.println("Enjoy your meal :--)");
    System.out.println();
    System.out.println();

    System.out.println("Using the .equals method for pizza size: " + p2.equals(p3));
    System.out.println("Using the compareTo method for slices: " + p1.compareTo(p3));
    System.out.println();

    System.out.println("Enter the number of rows in your 2D array: ");
    int rows = scan.nextInt();
    System.out.println("Enter the number of columns in your 2D array: ");
    int cols = scan.nextInt();

    // printing array to user
    System.out.println(
        "Here is a 2D array of pizza objects with " + rows + " rows and " + cols + " columns:");
    System.out.println();
    OrganizePizza pizzaObjects = new OrganizePizza(rows, cols);
    System.out.println(pizzaObjects.toString());
    System.out.println();

    // Create a loop that will continuously prompt the user to modify any of the
    // objects using mutator methods at any location in the 2D array. Print the 2D
    // array.

    int userInput = 0;
    while (userInput != 2) {

      System.out.println("Would you like to modify an object? Enter [1] for yes and [2] for no.");
      userInput = scan.nextInt();
      if (userInput == 1) {
        System.out.println("Enter int for the index value of the object's row");
        int row = scan.nextInt();
        System.out.println("Enter int for the index value of the object's column");
        int column = scan.nextInt();

        System.out.println("Enter a string for topping type: ");
        String toppingg = newScan.nextLine();
        pizzaObjects.getPizzas()[row][column].setToppingType(toppingg);

        System.out.println("Enter an int for how many slices you want: ");
        int slicess = scan.nextInt();
        pizzaObjects.getPizzas()[row][column].setSlices(slicess);

        System.out.println("\n\nHere is your modified array of pizzas: \n" + pizzaObjects.toString());

      } else if (userInput == 2) {
        break;
      }
    }

    /*
     * OrganizePizza copy1 = new OrganizePizza(rows, cols);
     * for (int r = 0; r < rows; r++)
     * {
     * for (int c = 0; c < cols; c++)
     * {
     * copy1.getPizzas()[r][c].setToppingType(pizzaObjects.getPizzas()[r][c].
     * getToppingType());
     * copy1.getPizzas()[r][c].setSlices(pizzaObjects.getPizzas()[r][c].getSlices())
     * ;
     * }
     * }
     */

    System.out.println();

    /*
     * String userInput = new String();
     * while(!(userInput.equals("nothing")))
     * {
     * String sizeVal = new String();
     * 
     * System.out.
     * println("What would you like to modify? \"size\" , \"slices\" , \"toppings\" , \"topping type\" , \"to-go\" , \"crust-fill\" , or \"cost\". If you don't want to modify anything, type \"nothing\""
     * );
     * userInput = scan.nextLine();
     * 
     * if(userInput.toLowerCase().equals("size"))
     * {
     * System.out.println("Set to \"small\" \"medium\" or \"large\" ?");
     * 
     * }
     * 
     * }
     */

    // Unsorted array
    System.out.println("\n\nUnsorted 2D array: ");
    System.out.println(pizzaObjects.toString());

    // copy1
    OrganizePizza copy1 = new OrganizePizza(rows, cols);
    for (int row = 0; row < pizzaObjects.getPizzas().length; row++) {
      for (int column = 0; column < pizzaObjects.getPizzas()[row].length; column++) {
        copy1.getPizzas()[row][column].setToppingType(pizzaObjects.getPizzas()[row][column].getToppingType());
        copy1.getPizzas()[row][column].setSlices(pizzaObjects.getPizzas()[row][column].getSlices());
      }
    }

    // sortRow
    System.out.println("\nCalling sortRow for row index 1 to sort in increasing order: ");
    copy1.sortRow(1);
    System.out.println(copy1.toString());
    System.out.println();

    // copy2
    OrganizePizza copy2 = new OrganizePizza(rows, cols);
    for (int row = 0; row < pizzaObjects.getPizzas().length; row++) {
      for (int column = 0; column < pizzaObjects.getPizzas()[row].length; column++) {
        copy2.getPizzas()[row][column].setToppingType(pizzaObjects.getPizzas()[row][column].getToppingType());
        copy2.getPizzas()[row][column].setSlices(pizzaObjects.getPizzas()[row][column].getSlices());
      }
    }

    // sortCol
    System.out.println("\nCalling sortColumn for column index 0 to sort in increasing order: ");
    copy2.sortCol(0);
    System.out.println(copy2.toString());
    System.out.println();

    // copy3
    OrganizePizza copy3 = new OrganizePizza(rows, cols);
    for (int row = 0; row < pizzaObjects.getPizzas().length; row++) {
      for (int column = 0; column < pizzaObjects.getPizzas()[row].length; column++) {
        copy3.getPizzas()[row][column].setToppingType(pizzaObjects.getPizzas()[row][column].getToppingType());
        copy3.getPizzas()[row][column].setSlices(pizzaObjects.getPizzas()[row][column].getSlices());
      }
    }

    // sortRowMajor
    System.out.println("\nCalling sortRowMajor: ");
    copy3.sortRowMajor();
    System.out.println(copy3.toString());
    System.out.println();

    // copy4
    OrganizePizza copy4 = new OrganizePizza(rows, cols);
    for (int row = 0; row < pizzaObjects.getPizzas().length; row++) {
      for (int column = 0; column < pizzaObjects.getPizzas()[row].length; column++) {
        copy4.getPizzas()[row][column].setToppingType(pizzaObjects.getPizzas()[row][column].getToppingType());
        copy4.getPizzas()[row][column].setSlices(pizzaObjects.getPizzas()[row][column].getSlices());
      }
    }

    // sortColMajor
    System.out.println("\nCalling sortColMajor: ");
    copy4.sortColMajor();
    System.out.println(copy4.toString());
    System.out.println();

    scan.close();
    newScan.close();

  }
}
